<div class="row p-3 mb-0 text-white" style="background-color: rgb(8, 8, 8); position: relative;">
    <div class="col-1 col-sm-4 col-lg-4"></div>
    <div class="col-10 col-sm-4 col-lg-4">
        <div class="row  text-center">
            <b>Giới thiệu</b> 
        </div>
       
       <ul>
        <li>
            Cửa hàng Coffee-DQB
        </li>
        <li>
            Địa chỉ: abcxyz
        </li>
        <li>
            Số điện thoại: 09876543
        </li>
       </ul>
    </div>
    <div class="col-1 col-sm-4 col-lg-4"></div>
</div>