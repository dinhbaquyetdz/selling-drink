@extends('web_chinh.layout.app')
@section('webchinh')

@include('web_chinh.layout.content')
@include('web_chinh.layout.footter')

@endsection