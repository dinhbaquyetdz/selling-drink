

<?php $__env->startSection('content'); ?>
    

<div class="row mt-5">
    <div class="row text-white">
      <div class="col-lg-3 col-sm-3 col-12">
        <h2><strong>Danh mục</strong></h2>
      </div>
      <div class="col-lg-6 col-sm-3 col-12">

      </div>
      <div class="col-lg-3 col-sm-6 col-12">
        <div class="row">
          <div class="col-lg-3 col-6">
            <a href="<?php echo e(Route('dpFormAddDanhmuc')); ?>">
              <button class="btn btn-success">Add</button></a>
            </a>
            
          </div>
          <div class="col-lg-9 col-6">
            <form class="d-flex" role="search">
              <input class="form-control" type="search" placeholder="Search..." aria-label="Search">
              <button class="btn btn-primary" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <table class="table table-hover table-bordered">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Tên danh mục</th>
          <th scope="col" class="text-center" colspan="2">Setting</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
        
        <tr>
          <th scope="row"><?php echo e($key+1); ?></th>
          <td><?php echo e($value->tendanhmuc); ?></td>
          <td><a href="<?php echo e(route('FormUpdateDanhmuc', ['id'=>$value->id])); ?>"><button type="button" class="btn btn-info">Sửa</button></a> </td>
           <td><a href="<?php echo e(route('deleteDanhmuc', ['id'=>$value->id])); ?>"><button type="button" class="btn btn-danger">Xóa</button></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/admin/manage/manageDanhmuc.blade.php ENDPATH**/ ?>