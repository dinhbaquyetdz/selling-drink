<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/home.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Trang chủ</title>
</head>
<body style="background-image: url('./image/background.jpg'); background-repeat: no-repeat;background-size: cover">
  <div class="container-lg">
    <div class="row">
      <div class="col-9 w-75 text-white">
       <strong> <h1 style="font-family:'Dancing Script'">Coffee DBQ</h1></strong>
       <h5>No one can change the past.</h5>
       <h5>But someone gotta try.</h5>
       <h5 style="font-size: 5px">Cre: MTP</h5>
      </div>
      <div class="col-3 text-white text-end username">
        <div class="dropdown mt-3">
          <a class="btn text-white" type="button" data-bs-toggle="dropdown" style="font-family:'Dancing Script'">
            Dinh Ba Quyet
          </a>
          <ul class="dropdown-menu p-0">
            <li><a class="dropdown-item" href="#">logout</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="row">
    <div class=" m-0 p-0 post">      
        <ul class="nav bg-black bg-gradient justify-content-end" data-bs-theme="dark">
            <li class="nav-item">
                <a class="nav-link active " aria-current="page" href="#">Home</a>
            </li>
            <li class="nav-item dropdown">
            <a class="nav-link "  href="#" role="button" aria-expanded="false">Giới thiệu</a>
            </li>
            <li class="nav-item">
            <a class="nav-link " href="#">Menu</a>
            </li>
            <li class="nav-item">
            <a class="nav-link " href="#" aria-disabled="true">Liên hệ</a>
            </li>
            <li>
              <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Search</button>
              </form>
            </li>
            
        </ul> 
        
        <div class="row">
          
            <div class=" col-12">
              <div class="row">
               
              </div>
                <div class="row text-center" > 
                  <ul>
                    <strong class="text-white" >
                      <marquee width=25% class="h1" style="font-family:initial">Have a good day!</marquee>
                  </strong>
                  </ul>
                    
                </div>      
            </div>
            
        </div>
        
    </div>
  </div>
   
   <div class="row">

   </div>
  </div>   
</body>
</html><?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/index.blade.php ENDPATH**/ ?>