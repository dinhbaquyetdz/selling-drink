<style>
.loai>ul>li>a{
    text-decoration: none;
    color: black;
}
li{
    list-style: none;
}
.loai>ul>li>a:hover{
    display: block;
    background-color: rgb(165, 90, 9);
    color:rgb(226, 224, 208);
}
.dm>h3{
    color:rgb(115, 100, 81);
}

.img{
    display:block;
	transition: all .3s ease;
}
.img:hover{
    position: relative;
    transform: scale(1.01);
}
.sp:hover{
    position: relative;
    transition: all .5s ease;
    transform: scale(1.05);
}

</style>

<?php $__env->startSection('webchinh'); ?>
<div class="row bg-white">
    <div class="col-lg-3 col-sm-3 col-12 bg-secondary-subtle">
        <div class="row fixed">
            <div class="col-12 text-center dm">
                <h3>Loại</h3>
            </div>
        </div>
        <hr>
        <div class="row sticky-top">
            <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-12 col-sm-12 col-4 loai">
                <ul class="nav flex-sm-column m-0">
                    
                      
                      <li class="nav-item h-50">
                        <a class="nav-link" aria-current="page" href="<?php echo e(route('dpProduct', ['id'=>$value->id])); ?>"><?php echo e($value->tendanhmuc); ?></a>
                      </li>
                    
                </ul>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
    <div class="col-9">
        <div class="row">
            <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-sm-4 col-6 my-2">
                <div class="row">
                    <div class="col-12 w-100 h-100 text-center shadow-sm sp" style="background-color:bisque">
                        <a href="<?php echo e(route('dpCTProduct', ['id'=>$value->id])); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <img src="image/<?php echo e($value->img); ?>" class="w-75 mt-1 rounded shadow-sm sp" alt="">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 mt-1" style="height: 50px;">
                                    <p class="m-0 w-100" ><a href="" class="text-decoration-none"><b><?php echo e($value->tensp); ?></b></a></p>    
                                </div>
                            </div>
                            
                            <p><?php echo e(number_format($value->gia)); ?>đ</p>
                        </a>
                        <a href="<?php echo e(route('dpCTProduct', ['id'=>$value->id])); ?>">
                            <button class="btn btn-outline-warning">Thêm giỏ hàng</button>
                        </a>
                    </div>
                </div>
                
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php echo $__env->make('web_chinh.layout.footter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('web_chinh.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/web_chinh/product/product.blade.php ENDPATH**/ ?>