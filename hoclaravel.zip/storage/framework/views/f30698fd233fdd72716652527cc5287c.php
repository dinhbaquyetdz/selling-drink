

<?php $__env->startSection('content'); ?>
<div class="row text-center">
    <form action="<?php echo e(route('updatePay', ['id'=>$id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <select name="thanhtoan" class="form-control">
            <option value="0">Thanh toán</option>
            <option value="0">Đã thanh toán</option>
            <option value="1">Chưa thanh toán</option>
        </select>
        
        <button class="btn btn-primary" type="submit">Xác nhận</button>
    </form>
    <?php if(session('success')): ?>
            <div style="color: rgb(23, 241, 23)">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/admin/manage/updateThanhtoan.blade.php ENDPATH**/ ?>