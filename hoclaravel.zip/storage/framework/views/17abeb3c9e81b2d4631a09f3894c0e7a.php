
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <title>UPDATEPASSWORD</title>
</head>

<body class="" style="width: 100%; height: 100%;">
<div class="container-lg w-100">
    <div class="row mt-5">
        <div class="col-lg-5 col-sm-12">
            <strong> <h1 style="font-family:'Dancing Script';font-size: 100px">Coffee DBQ</h1></strong>
        </div>
        <div class="col-lg-6 col-sm-10 shadow-lg rounded bg-white">
            <h4>Cập nhật lại mật khẩu.</h4>
        <form action="<?php echo e(route('updatePass')); ?>" method="post" class="p-1">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="email" value="<?php echo e($email); ?>">
            <div class="form-control">
                <label for="">Nhập mật khẩu:</label>
                <input type="text" class="form-control" name="password" placeholder="Nhập mật khẩu">
            </div>
            <div class="form-control">
                <label for="">Nhập lại mật khẩu:</label>
                <input type="text" class="form-control" name="repassword" placeholder="Nhập lại mật khẩu">
            </div>
            <button type="submit" class="btn btn-primary mt-3">Cập nhật</button>
            
        </form>
        <?php if($errors->any()): ?>
            <div class="">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="color: red; list-style: none;"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        </div>
        <div class="col-lg-1 col-sm-12"></div>
    </div>
    
</div>
</body>
</html><?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/updatePass.blade.php ENDPATH**/ ?>