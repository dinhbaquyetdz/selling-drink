

<?php $__env->startSection('content'); ?>
<div class="row text-center">
    <form action="<?php echo e(route('updateTT', ['id'=>$id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <select name="trangthai" class="form-control">
            <option value="0">Trạng thái</option>
            <option value="1">Chưa xác nhận</option>
            <option value="2">Đã xác nhận</option>
            <option value="3">Đang giao</option>
            <option value="4">Đã nhận</option>
        </select>
        
        <button class="btn btn-primary" type="submit">Xác nhận</button>
    </form>
    <?php if(session('success')): ?>
            <div style="color: rgb(23, 241, 23)">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/admin/manage/updateTrangthai.blade.php ENDPATH**/ ?>