

<?php $__env->startSection('content'); ?>
    

<div class="row mt-5">
    <div class="row text-white">
      <div class="col-lg-3 col-sm-3 col-12">
        <h2><strong>Đơn hàng</strong></h2>
      </div>
      <div class="col-lg-6 col-sm-3 col-12">

      </div>
      <div class="col-lg-3 col-sm-6 col-12">
        <form class="d-flex" role="search">
          <input class="form-control" type="search" placeholder="Search..." aria-label="Search">
          <button class="btn btn-primary" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
        </form>
      </div>
    </div>
    <table class="table table-hover table-bordered">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">tensp</th>
          <th scope="col">Ảnh</th>
          
          <th scope="col">Tổng tiền</th>
          <th scope="col">Số điện thoại</th>
          <th scope="col">Địa chỉ</th>
          <th scope="col">Ngày đặt</th>
          <th scope="col">Trạng thái</th>
          <th scope="col">Thanh toán</th>
          <th scope="col" class="text-center" colspan="3">Cập nhật</th>
        </tr>
      </thead>
      <tbody>
        <?php if(empty($data)): ?>
            <h4>Khách hàng này chưa mua sản phẩm nào!</h4>
        <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
        
        <tr>
          <th scope="row"><?php echo e($key+1); ?></th>
          <td><?php echo e($value->tensp); ?></td>
          <td><img src="/image/<?php echo e($value->img); ?>" alt="" style="width: 50px;"></td>
          <td><?php echo e($value->gia); ?></td>
          <td><?php echo e($value->phone); ?></td>
          <td><?php echo e($value->address); ?></td>
          <td><?php echo e($value->ngaydat); ?></td>
          <td>
            <?php if($value->trangthai == 1): ?>
                Chờ xác nhận
            <?php elseif($value->trangthai == 2): ?>
                Đã xác nhận
            <?php elseif($value->trangthai == 3): ?>
                Đang giao hàng
            <?php elseif($value->trangthai == 4): ?>
                Đã nhận hàng
            <?php endif; ?>
          </td>
          <td><?php echo e($value->thanhtoan == 1 ? "Chưa thanh toán" : "Đã thanh toán"); ?></td>
          <td> <a href="<?php echo e(route('dpUpdateTT', ['id'=>$value->id])); ?>"><button type="button" class="btn btn-warning">Trạng thái</button></a></td>
           <td><a href="<?php echo e(route('dpUpdatePay', ['id'=>$value->id])); ?>"><button type="button" class="btn btn-info">Thanh toán</button></a>
            <td>
              <form action="<?php echo e(route('deleteDonhang', ['id'=>$value->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id_khachhang" value="<?php echo e($value->id_khachhang); ?>">
                <button type="submit" class="btn btn-danger">Xóa</button>
              </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/admin/manage/manageDonhang.blade.php ENDPATH**/ ?>