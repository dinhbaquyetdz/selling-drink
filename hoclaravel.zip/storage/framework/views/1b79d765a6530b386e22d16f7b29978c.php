

<?php $__env->startSection('content'); ?>
    

<div class="row mt-5">
    
    <div class="row">
        <div class="col-sm-3 col-lg-3 col-1"></div>
        <div class="col-sm-6 col-lg-6 col-10 shadow p-3 mb-5 bg-body-tertiary rounded">
            <div class="row text-center">
                <h2>Thêm Sản Phẩm</h2>
            </div>
            
            <form method="POST" action="<?php echo e(Route('AddProduct')); ?>" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
                <div class="mb-3">
                 
                  <input type="text" name="tensp" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Tên sản phẩm">
                </div>
                <div class="mb-3">
                 
                  <input type="number" name="soluong" class="form-control" id="exampleInputPassword1" placeholder="Số lượng">
                </div>
                <div class="mb-3">
                   
                    <input type="number" name="gia" class="form-control" id="exampleInputPassword1" placeholder="Giá">
                </div>
                <div class="mb-3">
                    
                    <select name="loai" id="" class="form-control">
                      <option value="0">Loại</option>
                      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($value->id); ?>"><?php echo e($value->tendanhmuc); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>
                <div class="mb-3">
                   <label for="">Thông tin:</label>
                  <textarea name="thongtin" class="form-control" id="exampleInputPassword1"></textarea>
              </div>
                <div class="mb-3">
                    <label for="formFile" class="form-label">Chọn ảnh mô tả sản phẩm</label>
                    <input class="form-control" type="file" name="upload_file" id="formFile">
                </div>
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <button type="submit" class="btn btn-primary">Add</button>
                <a href="<?php echo e(Route('managentProduct')); ?>"><button type="button" class="btn btn-dark">Back</button></a>
                
              </form>
        </div>
        <div class="col-sm-3 col-lg-3 col-1"></div>
    </div>
    
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/admin/manage/addProducts.blade.php ENDPATH**/ ?>