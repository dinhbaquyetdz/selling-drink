

<?php $__env->startSection('content'); ?>
    

<div class="row mt-5">
    
    <div class="row">
        <div class="col-sm-3 col-lg-3 col-1"></div>
        <div class="col-sm-6 col-lg-6 col-10 shadow p-3 mb-5 bg-body-tertiary rounded">
            <div class="row text-center">
                <h2>Thêm Danh Mục</h2>
            </div>
            
            <form method="POST" action="<?php echo e(Route('addDanhmuc')); ?>">
              <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Tên danh mục</label>
                    <input type="text" name="tendanhmuc" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                    
                  </div>
                  
                  <button type="submit" class="btn btn-primary">Add</button>
                <a href="<?php echo e(Route('dpDanhmuc')); ?>"><button type="button" class="btn btn-dark">Back</button></a>
              </form>
        </div>
        <div class="col-sm-3 col-lg-3 col-1"></div>
    </div>
    
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/admin/manage/addDanhmuc.blade.php ENDPATH**/ ?>