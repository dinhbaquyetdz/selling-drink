
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <title>FORGOTPASSWORD</title>
</head>

<body class="" style="width: 100%; height: 100%;">
<div class="container-lg w-100">
    <div class="row mt-5">
        <div class="col-lg-5 col-sm-12">
            <strong> <h1 style="font-family:'Dancing Script';font-size: 100px">Coffee DBQ</h1></strong>
        </div>
        <div class="col-lg-6 col-sm-10 shadow-lg rounded bg-white">
            <h4>Vui lòng nhập mã xác nhận gồm 6 chữ số đã được gửi đến email của bạn.</h4>
        <form action="<?php echo e(route('checkCode',['token'=>$token])); ?>" method="get" class="p-1">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="code" value="<?php echo e($code); ?>">
            <input type="hidden" name="email" value="<?php echo e($email); ?>">
            <input type="text" class="form-control" name="code_mail" placeholder="Nhập mã xác nhận">
            <button type="submit" class="btn btn-primary mt-3">Kiểm tra</button>
            
        </form>
        <?php if($errors->any()): ?>
            <div class="">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="color: red; list-style: none;"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if($message = Session::get('error')): ?>
            <div style="color: red; list-style: none;">
                
                <?php echo e($message); ?>

            </div>
        <?php endif; ?>
        </div>
        <div class="col-lg-1 col-sm-12"></div>
    </div>
    
</div>
</body>
</html><?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/email/checkToken.blade.php ENDPATH**/ ?>