
<?php $__env->startSection('webchinh'); ?>
<div class="row bg-white">
    <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-6 col-sm-5 col-12 text-center mt-3">
        <img src="image/<?php echo e($value->img); ?>" class="w-75 h-75 rounded" alt="">
    </div>
    <div class="col-lg-5 col-sm-5 col-12">
        <div class="row">
            <div class="col-12">
                <form action="<?php echo e(route('addCart')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <h4>Sản phẩm:<b style="color: rgb(255, 140, 0)"><?php echo e($value->tensp); ?></b></h4> <hr>
                <input type="hidden" name="tensp" value="<?php echo e($value->tensp); ?>">
                <input type="hidden" name="id" value="<?php echo e($value->id); ?>">
                <h6><?php echo e($value->thongtin); ?></h6><hr> 
                <b style="color: rgb(255, 140, 0)"><h4><?php echo e(number_format($value->gia)); ?>đ</h4></b>
                <input type="hidden" name="gia" value="<?php echo e($value->gia); ?>">
                <input type="hidden" name="img" value="<?php echo e($value->img); ?>">
                <hr> 
                    <label for="">Số lượng: </label>
                    <input type="number" name="soluong" min="1" value="1" max="<?php echo e($value->soluong); ?>">
                    <hr>
                    
                    <button class="btn btn-warning text-white" type="submit">Thêm giỏ hàng<i class="fa fa-shopping-cart" ></i></button>
                </form>
                <hr>
                <h5>Mã sản phẩm: <b style="color:rgb(255, 140, 0)"><?php echo e($value->id); ?></b></h5>
                <hr>
                <h5>Loại: <b style="color:rgb(255, 140, 0)"><?php echo e($value->tendanhmuc); ?></b></h5>
            </div>
        </div>
        
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="col-1"></div>
    <hr>
    <div class="row">
        <div class="row">
            <div class="col-3 text-center">
                <h3 style="color:rgb(3, 75, 51);" class="text-decoration-underline">Bình luận</h3>
            </div>
        </div>
        <div class="row">
            CMT ở đây
        </div><hr>
    </div>
</div>
<?php echo $__env->make('web_chinh.layout.footter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web_chinh.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/web_chinh/product/CTproduct.blade.php ENDPATH**/ ?>