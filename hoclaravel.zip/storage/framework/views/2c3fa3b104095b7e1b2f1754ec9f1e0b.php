


<div class="row ">
    <div class="col-sm-3 col-lg-3 col-12 " style="background-color:rgb(58, 73, 106)">
      <div class="row " >
        <div class="col-12 p-0" >
          <hr class="m-0" style="color: rgb(134, 114, 114)">
            <p class="text-center mt-2" style="color: rgb(164, 142, 142)">interface</p>
          <div class="row">
            
            <ul class="nav flex-sm-column m-0">
            <div class="col-sm-12 col-lg-12 col-4 mb-2">
              <hr class="m-0" style="color: rgb(134, 114, 114)">
              <li class="nav-item h-50 side_content">
                <a class="nav-link" aria-current="page" href="#">Admin Managent </a>
              </li>
            </div>
            <div class="col-sm-12 col-lg-12 col-2 mb-2">
              <hr class="m-0" style="color: rgb(134, 114, 114)">
              <li class="nav-item side_content">
                <a class="nav-link" href="<?php echo e(Route('managentProduct')); ?>">Sản phẩm</a>
              </li>
            </div>
            <div class="col-sm-12 col-lg-12 col-2 mb-2">
              <hr class="m-0" style="color: rgb(134, 114, 114)">
              <li class="nav-item side_content">
                <a class="nav-link" href="<?php echo e(Route('dpDanhmuc')); ?>">Danh mục</a>
              </li>
            </div>
            
            <div class="col-sm-12 col-lg-12 col-2 mb-2">
              <hr class="m-0" style="color: rgb(134, 114, 114)">
              <li class="nav-item h-50 side_content">
                <a class="nav-link" href="<?php echo e(Route('dpMember')); ?>">Thành viên</a>
              </li>
            </div>
            <div class="col-12 text-center">
              <a href="#" class=" mt-2" style="color: rgb(134, 114, 114)">about me</a>
            </div>
            
          </ul>
          </div>
       
        </div>
      </div>
    </div>
    <?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>