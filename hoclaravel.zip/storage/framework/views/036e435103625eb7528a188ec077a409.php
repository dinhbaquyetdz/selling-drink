<style>
  .dropbtn {
    background-color: #0a0a0a;
    color: white;
    margin: 5px
    font-size: 16px;
    border: none;
  }
  
  .dropdown {
    position: relative;
    display: block;
  }
  .top{
    color: white;
  }
  .top:hover{
    color:rgb(248, 161, 11);
  }
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: rgb(12, 12, 11);
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    /* z-index: 1; */
    
  }
  
  .dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
  }
  
  .dropdown-content a:hover {background-color: antiquewhite; color: black}
  
  .dropdown:hover .dropdown-content {display: block;}
  
  .dropdown:hover .dropbtn {background-color: antiquewhite; color: black}
  </style>
<div class="container-fluid">
    <div class="row">
      <div class="col-lg-8 col-sm-12 text-white">
       <strong> <h1 style="font-family:'Dancing Script'">Coffee DBQ</h1></strong>
       <h5>No one can change the past.<br>
       But someone gotta try.</h5>
       <h5 style="font-size: 5px">Cre: MTP</h5>
      </div>
      <div class="col-lg-3 col-sm-12 text-white text-end username">
        <div class="dropdown my-4">
          
          <?php if(auth()->user()): ?>
          <div class="dropstart">
            <button class="btn text-white" type="button" data-bs-toggle="dropdown" aria-expanded="false">
              <?php echo e(Auth::user()->name); ?>

            </button>
            <ul class="dropdown-menu m-0 p-0">
              <li><a class="dropdown-item" href="<?php echo e(Route('dpInfo')); ?>">Thông tin cá nhân</a></li>
              <li><a class="dropdown-item" href="<?php echo e(Route('Logout')); ?>">Logout</a></li>
            </ul>
          </div>
          <?php else: ?>
          <a class=" text-decoration-none top" href="<?php echo e(Route('displayLogin')); ?>" style="font-family:'Dancing Script'">
            Đăng nhập
          </a>
          <a class=" text-decoration-none top" href="<?php echo e(Route('displayRegister')); ?>" style="font-family:'Dancing Script'">Đăng ký</a>
          
          <?php endif; ?>
          
          
        </div>
      </div>
    </div>
    <div class="row sticky-top">
    <div class=" m-0 p-0 post">      
        <ul class="nav bg-black bg-gradient justify-content-center" data-bs-theme="dark">
            <li class="nav-item">
                <a class="nav-link active " aria-current="page" href="<?php echo e(Route('index')); ?>">Home</a>
            </li>
            <li class="nav-item dropdown">
            <a class="nav-link "  href="#" role="button" aria-expanded="false">Giới thiệu</a>
            </li>
            <li class="nav-item">
              <li class="nav-item dropdown">
                <div class="dropdown">
                  <a href="<?php echo e(route('dpAllProduct')); ?>" class="nav-link "><button class="dropbtn">Menu</button></a>
                  <div class="dropdown-content">
                    <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ke =>$valu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('dpProduct', ['id'=>$valu->id])); ?>"><?php echo e($valu->tendanhmuc); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  </div>
                </div>
              </li>
            </li>
            <li class="nav-item">
            <a class="nav-link " href="#" aria-disabled="true">Liên hệ</a>
            </li>
            
            <li class="nav-item">
             
              <a class="nav-link " href="<?php echo e(Route('dpCart')); ?>" class="text-white text-decoration-none bg-black" style="border-radius: 100%"><i class="fa fa-shopping-cart" style="font-size: 25px"></i><i style="color: rgb(241, 20, 20); font-size: 15px"><?php echo e(is_array($data3) ? count($data3) : 0); ?></i></a>
              
            </li>
            
        </ul> 
        
        
        
    </div>
  </div>
   
  
  <?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/web_chinh/layout/header.blade.php ENDPATH**/ ?>