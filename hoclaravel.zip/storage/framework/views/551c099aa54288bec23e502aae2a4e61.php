
<?php $__env->startSection('webchinh'); ?>
<style>
.loai>ul>li>a{
    text-decoration: none;
    color: black;
}
li{
    list-style: none;
}
.loai>ul>li>a:hover{
    display: block;
    background-color: rgb(165, 90, 9);
    color:rgb(226, 224, 208);
}
.dm>h3{
    color:rgb(115, 100, 81);
}
#dpdonhang{
    height: 300px;
    overflow: auto;
    display: none;
}
#info{
    height: 300px;
    /* overflow: auto; */
    display: none;
}
#updateTT{
    /* height: 300px; */
    /* overflow: auto; */
    display: none;
}

</style>
<div class="row bg-white">
    <div class="col-sm-12 col-lg-3 border-end">
        <div class="row fixed">
            <div class="col-12 dm ms-3">
                <h3>MANAGENT</h3>
            </div>
        </div>
        <hr>
        <div class="row sticky-top"> 
            <div class="col-lg-12 col-sm-12 loai">
                <ul class="nav flex-sm-column m-0">
                      <li class="nav-item h-50">
                        <a class="nav-link" id="dh" onclick="return dpDonhang()">Đơn hàng đã mua</a>
                      </li>
                    
                </ul>
                <hr>
            </div> 
            <div class="col-lg-12 col-sm-12 loai">
                <ul class="nav flex-sm-column m-0">
                      <li class="nav-item h-50">
                        <a class="nav-link" aria-current="page" onclick="return dpTT()" id="thongtincanhan">Thông tin cá nhân</a>
                        
                      </li>
                    
                </ul>
                <hr>
            </div> 
            <div class="col-lg-12 col-sm-12 loai">
                <ul class="nav flex-sm-column m-0">
                      <li class="nav-item h-50">
                        <a class="nav-link" aria-current="page" onclick="return dpUd()" id="update">Chỉnh sửa thông tin</a>
                        
                        </li>
                    
                </ul>
                <hr>
            </div> 
        </div>
    </div>
    <div class="col-sm-12 col-lg-9">
        <div class="row" id="dpdonhang">
            <div class="col-12">
                <table class="table">
                    <?php
                    if(empty($data5)){
                        echo "<h4 style='color: red' class='text-center'>Chưa mua bất kỳ sản phẩm nào</h4>";
                    }else{ 
                    $tong=0
                    ?>
                    <tr>
                        <th>Tên</th>
                        <th>Ảnh</th>
                        <th>Số lượng</th>
                        <th>Giá</th>
                        <th>Địa chỉ</th>
                        <th>Ngày đặt</th>
                        <th>Trạng thái</th>
                        <th>Thanh toán</th>
                    </tr>
                    <?php $__currentLoopData = $data5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($value->tensp); ?></td>
                            <td><img src="image/<?php echo e($value->img); ?>" alt="" style="width: 50px"></td>
                           <td><?php echo e($value->soluong); ?></td>
                           <td><?php echo e(number_format($value->gia)); ?></td>
                            <td><?php echo e($value->address); ?></td>
                            <td><?php echo e($value->ngaydat); ?></td>
                            <td>
                                <?php if($value->trangthai == 1): ?>
                                    Chờ xác nhận
                                <?php elseif($value->trangthai == 2): ?>
                                    Đã xác nhận
                                <?php elseif($value->trangthai == 3): ?>
                                    Đang giao hàng
                                <?php elseif($value->trangthai == 4): ?>
                                    Đã nhận hàng
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($value->thanhtoan == 1 ? "Chưa thanh toán" : "đã thanh toán"); ?></td>
                            
                        </tr>    
                        <?php $tong = $tong+($value['gia'])*($value['soluong'])?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                </table>
                
                <?php } ?>
            </div>
        </div>
        
        <div class="row" id="info">
            <h3><b style="color: red">THÔNG TIN CÁ NHÂN</b></h3>
            <hr>
            <table class="table table-border">
                <tr>
                    <th>Họ và tên:</th>
                    <td><?php echo e(Auth::user()->name); ?></td>
                </tr>
                <tr>
                    <th>Email:</th>
                    <td><?php echo e(Auth::user()->email); ?></td>
                </tr>
                <tr>
                    <th>Địa chỉ:</th>
                    <td><?php echo e(Auth::user()->address); ?></td>
                </tr>
                <tr> 
                    <th>Giới tính:</th>
                    <td><?php echo e(Auth::user()->gender = 1 ? 'nam' : 'nữ'); ?></td>
                </tr>
                <tr> 
                    <th>Ngày sinh:</th>
                    <td><?php echo e(Auth::user()->dateOfBirth); ?></td>
                </tr>
            </table>
        </div>
        
        <div class="row" id="updateTT">
            <h3><b style="color: red">CHỈNH SỬA THÔNG TIN</b></h3>
            <hr>
            <form action="<?php echo e(route('updateuser',['id'=>Auth::user()->id])); ?>" name="myForm" method="post" onsubmit="return validateForm()" >
                <?php echo csrf_field(); ?>
                <div class="mb-2">
                    <label class="form-label">Họ và tên</label>
                    <input type="text" id="name" class="form-control" name="name" value="<?php echo e(Auth::user()->name); ?>" placeholder="Nhập họ và tên">
                </div>
                
                <div class="mb-2">
                    <label class="form-label">Địa chỉ</label>
                    <input type="text" id="address" class="form-control" name="address" value="<?php echo e(Auth::user()->address); ?>" placeholder="Nhập địa chỉ">
                </div>
                <div class="mb-2">
                    <label class="form-label">Ngày sinh</label>
                    <input type="text" id="dateOfBirth" class="form-control" name="dateOfBirth" value="<?php echo e(Auth::user()->dateOfBirth); ?>" placeholder="Nhập địa chỉ">
                </div>
                <div class="mb-2">
                    <input type="radio" id="gender" name="gender" value="1">Nam
                    <input type="radio" id="gender" name="gender" value="2">Nữ
                </div>
                <div id="err"></div>
                <button type="submit" id="submit" class="btn btn-primary">Cập nhật</button>
                
            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
    var dh = document.getElementById('dpdonhang');
    var tt = document.getElementById('info');
    var ud = document.getElementById('updateTT');
    var btndh = document.getElementById('dh');
    var btntt = document.getElementById('thongtincanhan');
    var btnud = document.getElementById('update');
    function dpDonhang(){
        dh.style.display = 'block';
        tt.style.display = 'none';
        ud.style.display = 'none';
        btndh.style.color = "blue";
        btntt.style.color = "black";
        btnud.style.color = "black";
    }
    function dpTT(){
        dh.style.display = 'none';
        tt.style.display = 'block';
        ud.style.display = 'none';
        btndh.style.color = "black";
        btntt.style.color = "blue";
        btnud.style.color = "black";
    }
    function dpUd(){
        dh.style.display = 'none';
        tt.style.display = 'none';
        ud.style.display = 'block';
        btndh.style.color = "black";
        btntt.style.color = "black";
        btnud.style.color = "blue";
    }
    function validateForm() {
    let name = document.forms["myForm"]["name"].value;
    let address = document.forms["myForm"]["address"].value;
    let dateOfBirth = document.forms["myForm"]["dateOfBirth"].value;
    let gender = document.forms["myForm"]["gender"].value;
    if (name == "") {
        alert("Họ và tên không được bỏ trống");
        return false;
    }else
    if (address == "") {
        alert("Địa chỉ không được bỏ trống");
        return false;
    }else
    if (dateOfBirth == "") {
        alert("Ngày sinh không được bỏ trống");
        return false;
    }else
    if (gender == "") {
        alert("Giới tính không được bỏ trống");
        return false;
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web_chinh.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\hoclaravel\resources\views/web_chinh/user/thongtin.blade.php ENDPATH**/ ?>